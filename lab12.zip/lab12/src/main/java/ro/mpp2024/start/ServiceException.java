package ro.mpp2024.start;

public class ServiceException extends Throwable{
    public ServiceException(Exception e) {
    }
}
